% function azi = getAzi(targets)
% returns the field azi from the struct targets
function azi = getAzi(targets)
    azi = targets.azi;
end